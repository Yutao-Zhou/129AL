string = input ("Enter string: ") # Asking user to give string input
for line in range(10): # making a loop that is going to do the following line if the condition (10 line) meet.
    print(string) # Pring the string which is defined to be the input from user
